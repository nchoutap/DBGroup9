
-- Creat a View for Restaurant Rating

CREATE VIEW Average_Restaurant_Rating AS
SELECT Restaurant_id, AVG(quality_rating) AS qual_rating, AVG(menu_rating) AS menu_rating, AVG(price_rating) AS price_rating,
			AVG(package_rating) AS package_rating, AVG(delivery_time_rating) AS delivery_rating
FROM Restaurant_Ratings
GROUP BY Restaurant_id;

-- Query a View to view the Restaurant Rating for Restaurant_id = 23045

SELECT * 
FROM Average_Restaurant_Rating
WHERE Restaurant_id = 23045;
