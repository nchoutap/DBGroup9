-- Create Stored Procedure to stored best menu rating of a restaurant

DELIMITER $$

CREATE PROCEDURE Best_Menu_Rating (IN id_of_Restaurant INT)
BEGIN
	SELECT
		Restaurant_id, MAX(menu_rating)
    FROM	
		Restaurant_Ratings
	WHERE 
		Restaurant_id = id_of_Restaurant;
END //

DELIMITER //
    
-- Call the Stored Procedure with argument values = 23045

CALL Best_Menu_Rating(23045);

-- -------------------------------------------------------------------------------------------------------------------------
    
-- Creat a View for Restaurant Rating

CREATE VIEW [Average Restaurant Rating] AS
SELECT Restaurant_id, AVG(quality_rating) AS qual_rating, AVG(menu_rating) AS menu_rating, AVG(price_rating) AS price_rating,
			AVG(package_rating) AS package_rating, AVG(delivery_time_rating) AS delivery_rating
FROM Restaurant_Ratings
GROUP BY Restaurant_id;

-- Query a View to view the Restaurant Rating for Restaurant_id = 23045

SELECT * 
FROM [Average Restaurant Rating]
WHERE Restaurant_id = 23045;

-- -------------------------------------------------------------------------------------------------------------------------

-- Create Index for Restaurants base on Name

CREATE INDEX idx_res_name
ON RESTAURANT(restaurant_name);

-- Create Index for Person base on Name

CREATE INDEX idx_person_name
ON PERSON(person_name);


		