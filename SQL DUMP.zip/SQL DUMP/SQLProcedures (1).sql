DELIMITER //
CREATE PROCEDURE `retrieve_order_details`(in order_id INT)
BEGIN
SELECT order_id, p.person_name as driver, pd.person_name as ordered_by,location_name,location_address
FROM campus_eats_fall2020.order AS o
INNER JOIN
	person AS p
	ON o.driver_id=p.person_id
	AND o.order_id=order_id
	INNER JOIN
	person AS pd
	ON o.person_id = pd.person_id
	AND o.order_id = order_id
	INNER JOIN
	location AS l
	ON o.location_id = l.location_id
	AND o.order_id = order_id;
END //

DELIMITER //
CREATE PROCEDURE `get_drivers_with_rating`(in rating INT)
BEGIN
SELECT person_name as Student_name, rating, cell as student_contact,graduation_year,major,s.type as college_type
From driver as d
INNER JOIN person as p
	INNER JOIN student as s
	ON s.student_id=d.student_id
	AND s.person_id=p.person_id
	AND d.rating=rating;
END //

