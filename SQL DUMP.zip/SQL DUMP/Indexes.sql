
-- Create Index for Restaurants base on Name

CREATE INDEX idx_res_name
ON RESTAURANT(restaurant_name);

-- Create Index for Person base on Name

CREATE INDEX idx_person_name
ON PERSON(person_name);